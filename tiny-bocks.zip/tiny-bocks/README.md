This datapack is built for Minecraft Java Edition V1.21
-------------------------------------------------------
Key Commands:

To get the movement book type the command-
/function tinyblocks:give/movement_tool

To get the spawn egg type the command-
/function tinyblocks:give/spawn_egg

In order to modify what block you are selecting; type this command-
/function tinyblocks:utility/change {"block":"minecraft:stone"}
change the json value of "block" to whatever block you are wanting
-------------------------------------------------------

This Agreement was made on the sixteenth day of june in 2024 by and between the creator and owner of the Minecraft datapack "Tiny Blocks," known as "DerpKing11, or DerpKing1" and any individual who downloads, uses, or distributes the "Tiny Blocks" datapack, known as the "User."

Ownership: The "Tiny Blocks" datapack is the exclusive property of DerpKing11. All rights remain with DerpKing11.

Usage: The User is granted a non-exclusive use of "Tiny Blocks" for personal, non-commercial purposes only.

Distribution: The User may distribute "Tiny Blocks" freely, provided this Agreement is included and credit is given to DerpKing11.

No Sale: "Tiny Blocks" shall not be sold or commercially exploited. The User agrees not to charge any fee for the datapack.

Modifications: The User may create and distribute non-commercial derivative works, provided credit is given to DerpKing11 and this Agreement is included.

By downloading, using, or distributing "Tiny Blocks," the User agrees to these terms.